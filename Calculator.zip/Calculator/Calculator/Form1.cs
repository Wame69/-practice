﻿using System;
using System.Data;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Обработка нажатий на цифровые кнопки
        private void button_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            // Проверка, является ли текущее значение "0" для очистки
            if (textBoxResult.Text == "0")
                textBoxResult.Clear();

            // Добавление текста кнопки к текущему вводу
            textBoxResult.Text += button.Text;
        }

        // Обработка нажатия кнопки "="
        private void buttonEquals_Click(object sender, EventArgs e)
        {
            try
            {
                string expression = textBoxResult.Text;

                // Замена функций для выполнения
                expression = ReplaceFunctions(expression);

                // Вычисление выражения
                var result = new DataTable().Compute(expression, null);
                textBoxResult.Text = result.ToString();
            }
            catch
            {
                textBoxResult.Text = "Error"; // Ошибка обработки
            }
        }

        // Обработка кнопки "C" (очистка)
        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBoxResult.Text = "0";
        }

        // Обработка кнопки для квадратного корня
        private void buttonSqrt_Click(object sender, EventArgs e)
        {
            textBoxResult.Text += "sqrt(";
        }

        // Обработка тригонометрических функций
        private void buttonTrig_Click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            textBoxResult.Text += button.Text + "("; // Добавляем функцию с открывающей скобкой
        }

        // Метод для замены функций в строке на математические методы
        private string ReplaceFunctions(string expression)
        {
            // Заменяем функции на вызовы методов
            expression = Regex.Replace(expression, @"sin\(([^)]+)\)", match => Math.Sin(Evaluate(match.Groups[1].Value)).ToString());
            expression = Regex.Replace(expression, @"cos\(([^)]+)\)", match => Math.Cos(Evaluate(match.Groups[1].Value)).ToString());
            expression = Regex.Replace(expression, @"tan\(([^)]+)\)", match => Math.Tan(Evaluate(match.Groups[1].Value)).ToString());
            expression = Regex.Replace(expression, @"sqrt\(([^)]+)\)", match => Math.Sqrt(Evaluate(match.Groups[1].Value)).ToString());

            return expression; // Возвращаем обновленное выражение
        }

        // Метод для вычисления простых арифметических выражений
        private double Evaluate(string expression)
        {
            // Поддержка более сложных выражений
            return Convert.ToDouble(new DataTable().Compute(expression, null));
        }
    }
}
